const CACHE_VERSION='mootsil-c216-network-first';
self.addEventListener('install',event=>self.skipWaiting());
self.addEventListener('activate',event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.map(k=>caches.delete(k))))
      .then(()=>self.clients.claim())
  );
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET') return;
  const url=new URL(req.url);
  const same=url.origin===self.location.origin;

  if(req.mode==='navigate' || (same && (url.pathname.endsWith('.html') || url.pathname==='/'))){
    event.respondWith(fetch(req,{cache:'no-store'}).catch(()=>caches.match(req)));
    return;
  }

  if(same){
    event.respondWith(
      fetch(req,{cache:'no-cache'})
        .then(resp=>{
          const copy=resp.clone();
          caches.open(CACHE_VERSION).then(cache=>cache.put(req,copy));
          return resp;
        })
        .catch(()=>caches.match(req))
    );
  }
});
