-- C158 · Permitir eliminación administrativa de marcaciones de asistencia.
-- Idempotente. No elimina datos al ejecutarse.
grant delete on table public.asistencia_registros to anon;

drop policy if exists mootsil_asistencia_anon_delete on public.asistencia_registros;
create policy mootsil_asistencia_anon_delete
on public.asistencia_registros
for delete
to anon
using (true);
