-- C156 · Estado administrativo compartido para eliminar divergencias entre sesiones.
-- Idempotente. Ejecutar una sola vez en Supabase SQL Editor.

create table if not exists public.estado_compartido (
  scope text primary key,
  payload jsonb not null default '{}'::jsonb,
  actualizado_por uuid null references public.usuarios(id) on delete set null,
  updated_at timestamptz not null default now()
);

alter table public.estado_compartido enable row level security;

grant select, insert, update, delete on public.estado_compartido to anon;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='estado_compartido' and policyname='mootsil_estado_compartido_anon_select') then
    create policy mootsil_estado_compartido_anon_select on public.estado_compartido for select to anon using (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='estado_compartido' and policyname='mootsil_estado_compartido_anon_insert') then
    create policy mootsil_estado_compartido_anon_insert on public.estado_compartido for insert to anon with check (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='estado_compartido' and policyname='mootsil_estado_compartido_anon_update') then
    create policy mootsil_estado_compartido_anon_update on public.estado_compartido for update to anon using (true) with check (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='estado_compartido' and policyname='mootsil_estado_compartido_anon_delete') then
    create policy mootsil_estado_compartido_anon_delete on public.estado_compartido for delete to anon using (true);
  end if;
end $$;
