-- MOOTSIL C157 · Permitir edición compartida de financiamientos y sus pagos
-- Ejecutar una sola vez en Supabase SQL Editor.

grant update on table public.financiamientos to anon;
grant update on table public.financiamiento_movimientos to anon;

drop policy if exists mootsil_financiamientos_anon_update on public.financiamientos;
create policy mootsil_financiamientos_anon_update
on public.financiamientos
for update
to anon
using (true)
with check (true);

drop policy if exists mootsil_fin_mov_anon_update on public.financiamiento_movimientos;
create policy mootsil_fin_mov_anon_update
on public.financiamiento_movimientos
for update
to anon
using (true)
with check (true);
