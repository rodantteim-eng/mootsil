grant delete on table public.financiamientos to anon;
grant delete on table public.financiamiento_movimientos to anon;

drop policy if exists mootsil_financiamientos_anon_delete on public.financiamientos;
create policy mootsil_financiamientos_anon_delete on public.financiamientos for delete to anon using (true);

drop policy if exists mootsil_financiamiento_mov_anon_delete on public.financiamiento_movimientos;
create policy mootsil_financiamiento_mov_anon_delete on public.financiamiento_movimientos for delete to anon using (true);
