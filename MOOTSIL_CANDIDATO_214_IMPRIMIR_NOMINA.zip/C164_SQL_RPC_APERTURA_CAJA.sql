create or replace function public.c164_guardar_apertura_caja(p_fecha date, p_payload jsonb, p_actualizado_por uuid default null)
returns public.caja_aperturas
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.caja_aperturas;
begin
  insert into public.caja_aperturas(fecha,payload,actualizado_por,updated_at)
  values (p_fecha, coalesce(p_payload,'{}'::jsonb), p_actualizado_por, now())
  on conflict (fecha) do update
    set payload = excluded.payload, actualizado_por = excluded.actualizado_por, updated_at = now()
  returning * into v_row;
  return v_row;
end;
$$;
grant execute on function public.c164_guardar_apertura_caja(date,jsonb,uuid) to anon;
