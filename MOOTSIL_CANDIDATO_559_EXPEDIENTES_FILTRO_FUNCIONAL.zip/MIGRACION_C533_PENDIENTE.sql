-- C532: instalar en Supabase ANTES de publicar index.html.
-- No altera los titulares permanentes ni los pagos existentes.
CREATE TABLE IF NOT EXISTS public.c532_recepciones_cajas (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 orden_id uuid NOT NULL REFERENCES public.ordenes_trabajo(id),
 operario_id uuid NOT NULL REFERENCES public.usuarios(id),
 tabla_id uuid NOT NULL REFERENCES public.tablas(id),
 fecha date NOT NULL,
 cantidad integer NOT NULL CHECK (cantidad BETWEEN 1 AND 999),
 estado text NOT NULL DEFAULT 'pendiente_pesaje' CHECK (estado IN ('pendiente_pesaje','pesado','anulado')),
 responsable_id uuid NOT NULL REFERENCES public.usuarios(id),
 creado_en timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.c532_recepciones_cajas ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.c532_recepciones_cajas FROM anon, authenticated;

CREATE TABLE IF NOT EXISTS public.c532_auxiliares_autorizados (
 usuario_id uuid PRIMARY KEY REFERENCES public.usuarios(id),
 autorizado_por uuid NOT NULL REFERENCES public.usuarios(id),
 autorizado_en timestamptz NOT NULL DEFAULT now(),
 activo boolean NOT NULL DEFAULT true
);
ALTER TABLE public.c532_auxiliares_autorizados ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.c532_auxiliares_autorizados FROM anon, authenticated;
-- Registrar auxiliares por ID únicamente tras verificar su identidad y autorización.

CREATE OR REPLACE FUNCTION public.c532_registrar_cajas(p_orden_id uuid,p_cantidad integer,p_pin text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public','extensions','pg_temp' AS $$
DECLARE v_actor uuid; v_rol text; v_orden public.ordenes_trabajo%ROWTYPE; v_id uuid;
BEGIN
 IF p_orden_id IS NULL OR p_cantidad NOT BETWEEN 1 AND 999 OR p_pin !~ '^[0-9]{4}$' THEN RAISE EXCEPTION 'Datos de recepción inválidos'; END IF;
 SELECT x.usuario_id,u.rol::text INTO v_actor,v_rol FROM public.verificar_pin(p_pin) x JOIN public.usuarios u ON u.id=x.usuario_id LIMIT 1;
 IF v_actor IS NULL OR NOT (
 v_actor = (SELECT operario_id FROM public.ordenes_trabajo WHERE id=p_orden_id)
 OR v_rol IN ('admin','dueño','encargado','encargado_rancho','galerista','ingeniero')
 OR EXISTS (SELECT 1 FROM public.c532_auxiliares_autorizados a WHERE a.usuario_id=v_actor AND a.activo=true)
) THEN RAISE EXCEPTION 'PIN sin autorización para recepción de cajas'; END IF;
 SELECT * INTO v_orden FROM public.ordenes_trabajo WHERE id=p_orden_id;
 IF NOT FOUND OR v_orden.operario_id IS NULL OR v_orden.estado='cancelada' OR v_orden.formula_id IS NOT NULL OR v_orden.notas_encargado NOT LIKE '[PLAN_COSECHA]%' OR v_orden.fecha_asignacion>CURRENT_DATE THEN RAISE EXCEPTION 'Orden de cosecha no válida'; END IF;
 INSERT INTO public.c532_recepciones_cajas(orden_id,operario_id,tabla_id,fecha,cantidad,responsable_id) VALUES(v_orden.id,v_orden.operario_id,v_orden.tabla_id,v_orden.fecha_asignacion,p_cantidad,v_actor) RETURNING id INTO v_id;
 RETURN jsonb_build_object('ok',true,'id',v_id,'cantidad',p_cantidad,'estado','pendiente_pesaje');
END $$;

CREATE OR REPLACE FUNCTION public.c532_confirmar_y_asignar(p_orden_id uuid,p_surco integer,p_pin text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public','extensions','pg_temp' AS $$
DECLARE v_actor uuid;v_rol text;v_ord public.ordenes_trabajo%ROWTYPE;v_hechos text[];v_total integer;v_ocupados integer[];v_libres integer[];v_candidato record;v_num integer;v_asignados integer:=0;
BEGIN
 IF p_orden_id IS NULL OR p_surco NOT BETWEEN 1 AND 100 OR p_pin !~ '^[0-9]{4}$' THEN RAISE EXCEPTION 'Confirmación inválida'; END IF;
 SELECT x.usuario_id,u.rol::text INTO v_actor,v_rol FROM public.verificar_pin(p_pin) x JOIN public.usuarios u ON u.id=x.usuario_id LIMIT 1;
 IF v_actor IS NULL THEN RAISE EXCEPTION 'PIN incorrecto o usuario inactivo'; END IF;
 SELECT * INTO v_ord FROM public.ordenes_trabajo WHERE id=p_orden_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'Orden no encontrada'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(v_ord.tabla_id::text||v_ord.fecha_asignacion::text,526));
 SELECT * INTO v_ord FROM public.ordenes_trabajo WHERE id=p_orden_id FOR UPDATE;
 IF v_actor IS DISTINCT FROM v_ord.operario_id AND v_rol NOT IN ('admin','dueño','encargado','encargado_rancho','galerista','ingeniero') THEN RAISE EXCEPTION 'Este PIN no corresponde al cosechador asignado ni a un encargado'; END IF;
 IF v_ord.estado NOT IN ('pendiente','en_proceso') OR v_ord.fecha_asignacion>CURRENT_DATE OR v_ord.formula_id IS NOT NULL OR v_ord.notas_encargado NOT LIKE '[PLAN_COSECHA]%' THEN RAISE EXCEPTION 'Orden de cosecha no habilitada'; END IF;
 IF NOT p_surco=ANY(coalesce(v_ord.surcos_asignados,'{}'::integer[])) THEN RAISE EXCEPTION 'Surco no asignado a este cosechador'; END IF;
 v_hechos:=coalesce(v_ord.surcos_completados,'{}'::text[]);
 IF NOT p_surco::text=ANY(v_hechos) THEN
  v_hechos:=array_append(v_hechos,p_surco::text);
  UPDATE public.ordenes_trabajo SET surcos_completados=v_hechos,estado='en_proceso',actualizado_en=now() WHERE id=v_ord.id;
 END IF;
 SELECT cantidad_surcos INTO v_total FROM public.tablas WHERE id=v_ord.tabla_id;
 IF v_total BETWEEN 1 AND 200 THEN
  SELECT coalesce(array_agg(DISTINCT n),'{}'::integer[]) INTO v_ocupados FROM public.ordenes_trabajo o CROSS JOIN LATERAL unnest(o.surcos_asignados) n WHERE o.tabla_id=v_ord.tabla_id AND o.fecha_asignacion=v_ord.fecha_asignacion AND o.estado<>'cancelada' AND o.formula_id IS NULL AND o.notas_encargado LIKE '[PLAN_COSECHA]%';
  SELECT coalesce(array_agg(n),'{}'::integer[]) INTO v_libres FROM generate_series(1,v_total) n WHERE NOT n=ANY(v_ocupados);
  FOR v_candidato IN SELECT o.id,o.operario_id FROM public.ordenes_trabajo o WHERE o.tabla_id=v_ord.tabla_id AND o.fecha_asignacion=v_ord.fecha_asignacion AND o.estado IN ('pendiente','en_proceso') AND o.formula_id IS NULL AND o.notas_encargado LIKE '[PLAN_COSECHA]%' AND cardinality(o.surcos_asignados)>0 AND NOT EXISTS(SELECT 1 FROM unnest(o.surcos_asignados) n WHERE NOT n::text=ANY(coalesce(o.surcos_completados,'{}'::text[]))) ORDER BY o.actualizado_en NULLS FIRST,o.id LOOP
   EXIT WHEN cardinality(v_libres)=0;
   v_num:=v_libres[1];
   UPDATE public.ordenes_trabajo SET surcos_asignados=array_append(surcos_asignados,v_num),actualizado_en=now() WHERE id=v_candidato.id;
   INSERT INTO public.c525_galera_movimientos(orden_id,tabla_id,surco,tipo,responsable_id,operario_id) VALUES(v_candidato.id,v_ord.tabla_id,v_num,'apoyo',v_actor,v_candidato.operario_id) ON CONFLICT DO NOTHING;
   v_libres:=v_libres[2:cardinality(v_libres)];v_asignados:=v_asignados+1;
  END LOOP;
 END IF;
 RETURN jsonb_build_object('ok',true,'surcos_completados',v_hechos,'asignados',v_asignados,'pendientes',coalesce(cardinality(v_libres),0));
END $$;
REVOKE ALL ON FUNCTION public.c532_registrar_cajas(uuid,integer,text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.c532_confirmar_y_asignar(uuid,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.c532_registrar_cajas(uuid,integer,text) TO anon,authenticated;
GRANT EXECUTE ON FUNCTION public.c532_confirmar_y_asignar(uuid,integer,text) TO anon,authenticated;

-- C535: La plantación se deriva de la tabla_id de la orden; no se acepta plantación ni tabla editable desde el cliente.
-- La recepción guarda orden_id y tabla_id, preservando el vínculo para consultar la plantación.
